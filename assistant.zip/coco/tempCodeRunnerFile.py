import keyboard
import time
while True:
    if keyboard.is_pressed('ctrl') and keyboard.is_pressed('a'):
        print('yes')
        break
    time.sleep(0.02)




